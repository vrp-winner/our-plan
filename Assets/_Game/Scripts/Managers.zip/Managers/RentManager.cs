using UnityEngine;
using Unity.Netcode;
using Systems;

namespace Managers
{
    public class RentManager : SingletonNetwork<RentManager>
    {
        public override void OnNetworkSpawn()
        {
            if (IsServer && TurnManager.Instance != null)
            {
                TurnManager.Instance.OnCycleChanged += HandleCycleEnd;
            }
        }

        private void HandleCycleEnd(int newCycle)
        {
            if (!IsServer) return;

            // ���ҵ���Ф÷�����᷹
            var allPlayers = GameObject.FindObjectsByType<PlayerStatus>(FindObjectsSortMode.None);
            foreach (var status in allPlayers)
            {
                // �鴷���ͧ�������ѹ�ء�ͺ��͹���ç���
            }
        }

        public override void OnNetworkDespawn()
        {
            if (IsServer && TurnManager.Instance != null)
                TurnManager.Instance.OnCycleChanged -= HandleCycleEnd;
        }
    }
}